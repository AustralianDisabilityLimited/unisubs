from templatetag_sugar.tests.tests import SugarTestCase
