=========================================================
 celery.backends.database
=========================================================

.. contents::
    :local:
.. currentmodule:: celery.backends.database

.. automodule:: celery.backends.database
    :members:
    :undoc-members:
