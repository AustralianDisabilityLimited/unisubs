DATABASE_ENGINE = 'sqlite3'

INSTALLED_APPS = [
    "templatetag_sugar",
    "templatetag_sugar.tests",
]
