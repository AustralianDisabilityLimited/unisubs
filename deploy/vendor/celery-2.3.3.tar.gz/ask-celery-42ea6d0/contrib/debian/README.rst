These init scripts have been deprecated,
please use ../generic-init.d instead.
