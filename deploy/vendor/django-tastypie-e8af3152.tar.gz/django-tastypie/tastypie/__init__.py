__author__ = 'Daniel Lindsley, Cody Soyland, Matt Croydon'
__version__ = (1, 0, 0, 'beta')
