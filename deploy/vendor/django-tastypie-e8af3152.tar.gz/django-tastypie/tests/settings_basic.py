from settings import *
INSTALLED_APPS.append('basic')

ROOT_URLCONF = 'basic.urls'
