from settings import *
INSTALLED_APPS.append('alphanumeric')

ROOT_URLCONF = 'alphanumeric.urls'
