====================================================
 celery.utils.dispatch.signal
====================================================

.. contents::
    :local:
.. currentmodule:: celery.utils.dispatch.signal

.. automodule:: celery.utils.dispatch.signal
    :members:
    :undoc-members:
