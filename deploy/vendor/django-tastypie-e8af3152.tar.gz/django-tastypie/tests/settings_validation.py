from settings import *
INSTALLED_APPS.append('basic')
INSTALLED_APPS.append('validation')

ROOT_URLCONF = 'validation.api.urls'
